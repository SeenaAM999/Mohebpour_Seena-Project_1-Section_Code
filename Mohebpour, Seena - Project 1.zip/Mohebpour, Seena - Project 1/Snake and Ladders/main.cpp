/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 *  Seena Mohebpour
 *  CIS-17C
 *  Project 1: Snakes and Ladders
 *  Fri. Nov. 01, 2024
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <iterator>
using namespace std;

void displayRules();
void displayBoard();
void setupPlayers(int& playerCount, string playerNames[], 
                  string playerColors[], string playerLabels[]);
void gameplayMenu(const string& playerName, int& playerPosition);
void checkLadderOrSnake(int& position);
void initializeSnakes();
void initializeLadders();
bool checkQuitGame(int choice);

map<int, int> snakes;
map<int, int> ladders;

int main(int argc, char** argv) {
    int choice;
    int playerCount;
    const int MAX_PLAYERS = 6;
    
    string playerNames[MAX_PLAYERS];
    string playerColors[MAX_PLAYERS];
    string playerLabels[MAX_PLAYERS];
    map<string, int> playerPositions;

    // Display Welcome Message
    cout << "Welcome to Snakes and Ladders!" << endl;
    cout << "=============================" << endl;

    // Initialize snakes and ladders
    initializeSnakes();
    initializeLadders();

    // Main Menu Loop
    do {
        cout << endl << "Main Menu:" << endl;
        cout << "1. Explain the Rules of the Game" << endl;
        cout << "2. Display the Board with Snakes and Ladders" << endl;
        cout << "3. Start Playing the Game" << endl;
        cout << "Enter your choice (1-3): ";
        cin >> choice;

        // Handle Menu Choices
        switch (choice) {
            case 1:
                displayRules();
                break;
                
            case 2:
                displayBoard();
                break;
                
            case 3:
                cout << "Starting the game..." << endl;
                
                // Setup players
                setupPlayers(playerCount, playerNames, playerColors, playerLabels);

                // Initialize player positions to 0
                for (int i = 0; i < playerCount; ++i) {
                    playerPositions[playerLabels[i]] = 0;
                }

                // Begin gameplay loop
                for (int currentPlayer = 0;; currentPlayer = (currentPlayer + 1) % playerCount) {
                    // Show the gameplay menu for each player
                    gameplayMenu(playerNames[currentPlayer], playerPositions[playerLabels[currentPlayer]]);

                    // Check if the player has won by reaching or surpassing position 100
                    if (playerPositions[playerLabels[currentPlayer]] == 100) {
                        cout << playerNames[currentPlayer] << " has won the game!" << endl;
                        return 0; // Exit the game after a player wins
                    }
                }

                break;
                
            default:
                cout << "Invalid choice. Please select an option between 1 and 3." << endl;
        }
        
    } while (choice != 3);

    return 0;
}

void displayRules() {
    cout << endl << "Game Rules:" << endl;
    cout << "--------------------------" << endl;
    cout << "1. Players take turns rolling a dice to move their token along the board." << endl;
    cout << "2. If a player lands at the base of a ladder, they move up to its top." << endl;
    cout << "3. If a player lands on a snake's head, they slide down to its tail." << endl;
    cout << "4. The first player to reach square 100 wins the game!" << endl;
    cout << "--------------------------" << endl;
}

void displayBoard() {
    const int SIZE = 10;
    int counter = 1;

    cout << endl << "Board Game:" << endl;

    // Print the top border and board
    for (int row = 0; row < SIZE; ++row) {
        for (int col = 0; col < SIZE; ++col) {
            cout << "+----"; // Create the border
        }
        cout << "+" << endl;

        for (int col = 0; col < SIZE; ++col) {
            cout << "|";
            if (counter <= 99) {
                cout << setw(4) << counter;  // Number alignment (top-right)
            } else {
                cout << " " << counter;      // For number 100
            }
            counter++;
        }
        cout << "|" << endl;
    }

    // Last border line
    for (int col = 0; col < SIZE; ++col) {
        cout << "+----";
    }
    cout << "+" << endl;

    // Display table of snakes and ladders
    cout << endl << "Snakes and Ladders Coordinates Table:" << endl;
    cout << "+--------+--------+------+--------+--------+------+" << endl;
    cout << "| Ladders                | Snakes                 |" << endl;
    cout << "+--------+--------+------+--------+--------+------+" << endl;
    cout << "| Type   | Start  | End  | Type   | Start  | End  |" << endl;
    cout << "+--------+--------+------+--------+--------+------+" << endl;
    
    // Add the ladders and snakes in the format of a table
    cout << "| L1     |   2    |  15  | S1     |  20    |   8  |" << endl;
    cout << "| L2     |  32    |  48  | S2     |  49    |  40  |" << endl;
    cout << "| L3     |  40    |  57  | S3     |  68    |  23  |" << endl;
    cout << "| L4     |  51    |  67  | S4     |  72    |  60  |" << endl;
    cout << "| L5     |  60    |  80  | S5     |  86    |  56  |" << endl;
    cout << "| L6     |  79    |  95  | S6     |  92    |  83  |" << endl;
    cout << "+--------+--------+------+--------+--------+------+" << endl;
}

void setupPlayers(int& playerCount, string playerNames[], string playerColors[], string playerLabels[]) {
    cout << "\nEnter the number of players (2 to 6): ";
    cin >> playerCount;

    if (playerCount < 2) {
        cout << "Not enough players to play. Need at least 2 players." << endl;
        playerCount = 2; // Default to 2 players if invalid
    } else if (playerCount > 6) {
        cout << "Too many players. Maximum allowed is 6." << endl;
        playerCount = 6; // Default to 6 players if invalid
    }

    for (int i = 0; i < playerCount; ++i) {
        cout << "\nEnter Player " << (i + 1) << " Name: ";
        cin >> playerNames[i];
        
        cout << "Enter " << playerNames[i] << "'s Token Color: ";
        cin >> playerColors[i];

        // Create a label by using the first letters of name and color
        playerLabels[i] = playerNames[i].substr(0, 1) + "." + playerColors[i].substr(0, 1) + ".";
        
        cout << "Label created for " << playerNames[i] << ": " << playerLabels[i] << endl;
    }
}
// Function definitions
void initializeSnakes() {
    snakes.insert(std::make_pair(20, 8));
    snakes.insert(std::make_pair(49, 40));
    snakes.insert(std::make_pair(60, 23));
    snakes.insert(std::make_pair(72, 60));
    snakes.insert(std::make_pair(86, 56));
    snakes.insert(std::make_pair(92, 83));
}

void initializeLadders() {
    ladders.insert(std::make_pair(2, 15));
    ladders.insert(std::make_pair(32, 48));
    ladders.insert(std::make_pair(40, 57));
    ladders.insert(std::make_pair(51, 67));
    ladders.insert(std::make_pair(60, 80));
    ladders.insert(std::make_pair(79, 95));
}

// Function to update the player position if on a ladder or snake
void checkLadderOrSnake(int& position) {
    // Check if the player landed on a ladder
    if (ladders.find(position) != ladders.end()) {
        cout << "Landed on a ladder! Moving to " << ladders[position] << endl;
        position = ladders[position];
    }
    // Check if the player landed on a snake
    else if (snakes.find(position) != snakes.end()) {
        cout << "Landed on a snake! Sliding down to " << snakes[position] << endl;
        position = snakes[position];
    }
}

// Function to check if a player wants to quit the game
bool checkQuitGame(int choice) {
    if (choice == 2) {  // 2 is the quit choice
        cout << "Game Over" << endl;
        return true;
    }
    return false;
}

// Modified gameplayMenu function
void gameplayMenu(const string& playerName, int& playerPosition) {
    int choice;
    cout << "\nIt's " << playerName << "'s turn!" << endl;
    cout << "1) Play the Game" << endl;
    cout << "2) Quit Game" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    if (checkQuitGame(choice)) {
        exit(0);  // Ends the game immediately
    } else if (choice == 1) {
        int roll1 = rand() % 6 + 1;
        int roll2 = rand() % 6 + 1;
        int totalRoll = roll1 + roll2;

        cout << endl << playerName << " rolled a " << totalRoll << " (" << roll1 << " and " << roll2 << ")." << endl;
        playerPosition += totalRoll;

        // Prevent going over space 100
        if (playerPosition > 100) {
            playerPosition = 100;  // Stop at 100
        }

        cout << playerName << " landed on space " << playerPosition << "." << endl;

        checkLadderOrSnake(playerPosition);

        // If doubles rolled, allow an extra turn
        if (roll1 == roll2) {
            cout << playerName << " rolled doubles, so they get another turn." << endl;
            gameplayMenu(playerName, playerPosition);
        }
    }
}